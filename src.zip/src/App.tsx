import { Header } from "./components/Header";
import { ThemeToggle } from "./components/ThemeToggle";
import React from "react";
import {
  Box,
  Typography,
  TextField,
  RadioGroup,
  FormControlLabel,
  Radio,
  List,
  ListItem,
  Button,
  Tabs,
  Tab,
  IconButton,
  Paper,
} from "@mui/material";
import {
  AutoFixHigh,
  RestartAlt,
  Hub,
  AttachFile,
  Mic,
} from "@mui/icons-material";

/* -------------------------------------------------------
   COLUMN 1 — SIDEBAR
------------------------------------------------------- */
function Sidebar() {
  return (
    <Box
      sx={{
        width: "100%",
        p: 2,
        borderRight: "1px solid",
        borderColor: "divider",
        bgcolor: "background.paper",
        display: "flex",
        flexDirection: "column",
        gap: 2,
      }}
    >
      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
        Agent Network
      </Typography>

      <Box>
        <Typography variant="caption" sx={{ color: "text.secondary" }}>
          Protocol
        </Typography>
        <RadioGroup row defaultValue="http" sx={{ mt: 0.5 }}>
          <FormControlLabel value="http" control={<Radio size="small" />} label="http" />
          <FormControlLabel value="https" control={<Radio size="small" />} label="https" />
        </RadioGroup>
      </Box>

      <Box>
        <Typography variant="caption" sx={{ color: "text.secondary" }}>
          Host
        </Typography>
        <TextField size="small" fullWidth defaultValue="localhost" sx={{ mt: 0.5 }} />
      </Box>

      <Box>
        <Typography variant="caption" sx={{ color: "text.secondary" }}>
          Port
        </Typography>
        <TextField size="small" fullWidth defaultValue="8080" sx={{ mt: 0.5 }} />
      </Box>

      <Box sx={{ flex: 1, minHeight: 0 }}>
        <Typography variant="caption" sx={{ color: "text.secondary" }}>
          Available Agents
        </Typography>

        <Paper
          variant="outlined"
          sx={{
            mt: 1,
            maxHeight: "100%",
            overflow: "auto",
            bgcolor: "background.default",
          }}
        >
          <List dense>
            {[
              "airline_policy",
              "advanced_calendar",
              "smart_home",
              "smart_home_onf",
              "agent_network_designer",
              "agent_network_gen",
              "music_nerd",
              "music_nerd_local",
              "music_nerd_pro",
              "music_nerd_pro_sly",
            ].map((a) => (
              <ListItem
                key={a}
                sx={{
                  py: 0.75,
                  px: 1.5,
                  fontSize: 13,
                  borderBottom: "1px solid rgba(255,255,255,0.05)",
                }}
              >
                {a}
              </ListItem>
            ))}
          </List>
        </Paper>
      </Box>
    </Box>
  );
}

/* -------------------------------------------------------
   COLUMN 2 — CANVAS (Agent Designer)
------------------------------------------------------- */
function Canvas() {
  return (
    <Box
      sx={{
        flex: 1,
        position: "relative",
        bgcolor: "#05060a",
        display: "flex",
        flexDirection: "column",
        borderBottom: "1px solid",
        borderColor: "divider",
      }}
    >
      <Box
        sx={{
          p: 1.5,
          borderBottom: "1px solid",
          borderColor: "divider",
          display: "flex",
          gap: 1,
        }}
      >
        <Button size="small" variant="outlined" startIcon={<AutoFixHigh />}>
          Auto Arrange
        </Button>
        <Button size="small" variant="outlined" startIcon={<RestartAlt />}>
          Reset
        </Button>
      </Box>

      <Box sx={{ position: "absolute", top: 120, left: 180 }}>
        <Paper
          variant="outlined"
          sx={{
            px: 2,
            py: 1.25,
            display: "inline-flex",
            alignItems: "center",
            gap: 1,
            bgcolor: "background.paper",
          }}
        >
          <Hub fontSize="small" color="primary" />
          <Typography variant="body2" sx={{ fontWeight: 600 }}>
            agent_network_designer
          </Typography>
        </Paper>
      </Box>
    </Box>
  );
}

/* -------------------------------------------------------
   COLUMN 2 — LOGS + INFO (bottom row)
------------------------------------------------------- */
function Logs() {
  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
        Logs
      </Typography>

      <Paper
        variant="outlined"
        sx={{
          p: 1,
          bgcolor: "background.default",
          height: "100%",
        }}
      >
        <Typography
          component="pre"
          sx={{
            m: 0,
            fontFamily: "monospace",
            fontSize: 11,
            color: "text.secondary",
          }}
        >
{`{2026-04-20 07:27:43}: None (Frontend): System Initialized
{2026-04-20 07:27:43}: None (Frontend): Frontend app loaded successfully.`}
        </Typography>
      </Paper>
    </Box>
  );
}

function Info() {
  return (
    <Box sx={{ p: 2 }}>
      <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
        Sustainability Score
      </Typography>

      <Typography variant="body2" sx={{ fontSize: 13 }}>Energy: 0.00 kWh</Typography>
      <Typography variant="body2" sx={{ fontSize: 13 }}>Carbon: 0.00 g CO2</Typography>
      <Typography variant="body2" sx={{ fontSize: 13 }}>Water: 0.00 Litre</Typography>
      <Typography variant="body2" sx={{ fontSize: 13, mb: 2 }}>Cost: $0.00</Typography>

      <Typography variant="subtitle2" sx={{ mb: 1, fontWeight: 600 }}>
        Resources
      </Typography>

      <Typography variant="body2" sx={{ fontSize: 13 }}>NeuroSan v0.5.23</Typography>
      <Typography variant="body2" sx={{ fontSize: 13 }}>Client v0.5.10</Typography>
      <Typography variant="body2" sx={{ fontSize: 13 }}>Documentation</Typography>
    </Box>
  );
}

/* -------------------------------------------------------
   COLUMN 3 — CHAT PANEL
------------------------------------------------------- */
function ChatPanel() {
  const [tab, setTab] = React.useState(0);

  return (
    <Box
      sx={{
        width: "100%",
        bgcolor: "background.paper",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Tabs
        value={tab}
        onChange={(_, v) => setTab(v)}
        variant="fullWidth"
        sx={{
          borderBottom: "1px solid",
          borderColor: "divider",
          "& .MuiTab-root": { fontSize: 12, textTransform: "none" },
        }}
      >
        <Tab label="Chat" />
        <Tab label="Internal Chat" />
        <Tab label="SlyData" />
        <Tab label="Config" />
      </Tabs>

      <Box sx={{ flex: 1, p: 2, overflow: "auto" }}>
        <Paper sx={{ mb: 1.5, p: 1, bgcolor: "rgba(255,255,255,0.04)" }}>
          <Typography variant="body2">Welcome to the chat</Typography>
        </Paper>

        <Paper
          sx={{
            mb: 1.5,
            p: 1,
            bgcolor: "rgba(79,140,255,0.16)",
            border: "1px solid rgba(79,140,255,0.5)",
          }}
        >
          <Typography variant="body2">
            Build me an agent network that can take care of the upcoming sale weekend.
          </Typography>
        </Paper>
      </Box>

      <Box
        sx={{
          p: 1.5,
          borderTop: "1px solid",
          borderColor: "divider",
          display: "flex",
          gap: 1,
          alignItems: "center",
        }}
      >
        <TextField size="small" fullWidth placeholder="Type a message..." />
        <IconButton size="small"><AttachFile fontSize="small" /></IconButton>
        <IconButton size="small"><Mic fontSize="small" /></IconButton>
        <Button variant="contained" size="small">Send</Button>
      </Box>
    </Box>
  );
}

/* -------------------------------------------------------
   MAIN APP LAYOUT (3 columns)
------------------------------------------------------- */
export default function App() {
  return (
    <Box
      sx={{
        height: "100vh",
        display: "grid",
        gridTemplateColumns: "260px 1fr 360px",
        bgcolor: "background.default",
      }}
    >
      <Sidebar />

      {/* Middle column: Canvas + Logs/Info */}
      <Box sx={{ display: "flex", flexDirection: "column", minHeight: 0 }}>
        <Canvas />

        <Box
          sx={{
            height: 200,
            display: "grid",
            gridTemplateColumns: "1fr 300px",
            borderTop: "1px solid",
            borderColor: "divider",
            bgcolor: "background.paper",
          }}
        >
          <Logs />
          <Info />
        </Box>
      </Box>

      <ChatPanel />
    </Box>
  );
}
